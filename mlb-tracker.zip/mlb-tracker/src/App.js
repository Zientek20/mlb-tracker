import { useState, useEffect, useCallback } from "react";

const CATEGORIES = ["Total Hits", "Singles", "Game Total Doubles"];
const STORAGE_KEY = "mlb_lines_tracker_v2";

const defaultLine = () => ({ line: "", overOdds: "", underOdds: "", result: "" });

const defaultGame = (date) => ({
  id: Date.now() + Math.random(),
  date: date || new Date().toISOString().slice(0, 10),
  homeTeam: "",
  awayTeam: "",
  lines: {
    "Total Hits": { home: defaultLine(), away: defaultLine() },
    "Singles": { home: defaultLine(), away: defaultLine() },
    "Game Total Doubles": { game: defaultLine() },
  },
  locked: false,
});

function parseOdds(odds) {
  const n = parseInt(odds, 10);
  return isNaN(n) ? null : n;
}

function oddsToImplied(odds) {
  const n = parseOdds(odds);
  if (n === null) return null;
  return n > 0 ? 100 / (n + 100) : Math.abs(n) / (Math.abs(n) + 100);
}

function formatPct(v) {
  return v === null ? "-" : (v * 100).toFixed(1) + "%";
}

function oddsColor(odds) {
  const n = parseOdds(odds);
  if (n === null) return "#94a3b8";
  if (n <= -150) return "#34d399";
  if (n <= -110) return "#86efac";
  if (n < 0) return "#fcd34d";
  return "#f87171";
}

function analyzeTrends(games) {
  const buckets = {};
  games.forEach((g) => {
    if (!g.locked) return;
    const process = (label, lineObj, side) => {
      const odds = side === "Over" ? lineObj.overOdds : lineObj.underOdds;
      const result = lineObj.result;
      if (!odds || !result) return;
      const n = parseOdds(odds);
      if (n === null) return;
      let bucket;
      if (n <= -200) bucket = "-200 or less";
      else if (n <= -150) bucket = "-150 to -199";
      else if (n <= -110) bucket = "-111 to -149";
      else if (n < 0) bucket = "-101 to -109";
      else bucket = "+100 or more";
      const key = `${label}|${side}|${bucket}`;
      if (!buckets[key]) buckets[key] = { hit: 0, total: 0, label, side, bucket };
      buckets[key].total++;
      if (result === side) buckets[key].hit++;
    };
    ["Total Hits", "Singles"].forEach((cat) => {
      ["home", "away"].forEach((t) => {
        const lo = g.lines[cat]?.[t];
        if (lo) { process(`${cat} (${t})`, lo, "Over"); process(`${cat} (${t})`, lo, "Under"); }
      });
    });
    const dl = g.lines["Game Total Doubles"]?.game;
    if (dl) { process("Game Total Doubles", dl, "Over"); process("Game Total Doubles", dl, "Under"); }
  });
  return Object.values(buckets).sort((a, b) => b.total - a.total);
}

// ── Storage helpers ──────────────────────────────────────────────────────────
function loadGames() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveGames(games) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(games)); } catch {}
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [games, setGames] = useState(loadGames);
  const [activeTab, setActiveTab] = useState("today");
  const [filterDate, setFilterDate] = useState(new Date().toISOString().slice(0, 10));
  const [toast, setToast] = useState(null);

  useEffect(() => { saveGames(games); }, [games]);

  const showToast = (msg, color = "#34d399") => {
    setToast({ msg, color });
    setTimeout(() => setToast(null), 2500);
  };

  const setAndSave = (updater) => setGames((prev) => typeof updater === "function" ? updater(prev) : updater);

  const addGame = () => setAndSave((prev) => [...prev, defaultGame(filterDate)]);
  const removeGame = (id) => setAndSave((prev) => prev.filter((g) => g.id !== id));
  const lockGame = (id) => setAndSave((prev) => prev.map((g) => g.id === id ? { ...g, locked: !g.locked } : g));
  const updateGame = (id, path, value) => setAndSave((prev) =>
    prev.map((g) => {
      if (g.id !== id) return g;
      const clone = JSON.parse(JSON.stringify(g));
      let obj = clone;
      for (let i = 0; i < path.length - 1; i++) obj = obj[path[i]];
      obj[path[path.length - 1]] = value;
      return clone;
    })
  );

  // Export
  const handleExport = () => {
    const blob = new Blob([JSON.stringify(games, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `mlb-tracker-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast("✅ Backup exported!");
  };

  // Import
  const handleImport = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        if (Array.isArray(data)) {
          setAndSave(data);
          showToast("✅ Data imported successfully!");
        } else { showToast("❌ Invalid file format", "#f87171"); }
      } catch { showToast("❌ Could not read file", "#f87171"); }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const todayGames = games.filter((g) => g.date === filterDate);
  const allGames = [...games].sort((a, b) => b.date.localeCompare(a.date));
  const trends = analyzeTrends(games);

  return (
    <div style={{ background: "#0f1923", minHeight: "100vh", fontFamily: "'Inter','Segoe UI',sans-serif", color: "#e2e8f0" }}>
      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", top: 16, left: "50%", transform: "translateX(-50%)", background: "#1e293b", border: `1px solid ${toast.color}`, color: toast.color, padding: "10px 20px", borderRadius: 8, zIndex: 9999, fontWeight: 700, fontSize: 14, boxShadow: "0 4px 20px #0008" }}>
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#1e3a5f 0%,#0f1923 100%)", borderBottom: "2px solid #1e40af", padding: "20px 16px 0", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 26 }}>⚾</span>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 19, fontWeight: 800, color: "#f0f9ff" }}>MLB Lines Tracker</div>
              <div style={{ fontSize: 11, color: "#64748b", letterSpacing: 2, textTransform: "uppercase" }}>DraftKings Research</div>
            </div>
            {/* Backup buttons */}
            <button onClick={handleExport} title="Export backup" style={iconBtn("#1e3a5f", "#38bdf8")}>⬇ Export</button>
            <label title="Import backup" style={{ ...iconBtn("#1e3a5f", "#a78bfa"), cursor: "pointer" }}>
              ⬆ Import
              <input type="file" accept=".json" onChange={handleImport} style={{ display: "none" }} />
            </label>
          </div>
          <div style={{ display: "flex", gap: 2 }}>
            {[{ id: "today", label: "Daily Entry" }, { id: "history", label: "History" }, { id: "trends", label: "Trends" }].map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} style={{ padding: "8px 16px", background: activeTab === tab.id ? "#1d4ed8" : "transparent", color: activeTab === tab.id ? "#fff" : "#64748b", border: "none", borderRadius: "6px 6px 0 0", cursor: "pointer", fontWeight: 600, fontSize: 13 }}>
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "20px 12px" }}>
        {activeTab === "today" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
              <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)}
                style={{ background: "#1e293b", border: "1px solid #334155", color: "#e2e8f0", padding: "7px 10px", borderRadius: 6, fontSize: 13 }} />
              <span style={{ color: "#64748b", fontSize: 12 }}>{todayGames.length} game{todayGames.length !== 1 ? "s" : ""}</span>
              <button onClick={addGame} style={{ marginLeft: "auto", background: "#1d4ed8", color: "#fff", border: "none", padding: "9px 18px", borderRadius: 8, cursor: "pointer", fontWeight: 700, fontSize: 13 }}>+ Add Game</button>
            </div>
            {todayGames.length === 0 && <EmptyState icon="⚾" title="No games for this date" sub='Tap "+ Add Game" to start logging lines' />}
            {todayGames.map((g) => <GameCard key={g.id} game={g} onUpdate={updateGame} onRemove={removeGame} onLock={lockGame} />)}
          </div>
        )}
        {activeTab === "history" && (
          <div>
            <div style={{ marginBottom: 12, color: "#64748b", fontSize: 12 }}>{allGames.filter(g => g.locked).length} completed games</div>
            {allGames.length === 0 && <EmptyState icon="📋" title="No games logged yet" sub="Add games in the Daily Entry tab" />}
            {allGames.map((g) => <GameCard key={g.id} game={g} onUpdate={updateGame} onRemove={removeGame} onLock={lockGame} />)}
          </div>
        )}
        {activeTab === "trends" && <TrendsTab trends={trends} games={games} />}
      </div>
    </div>
  );
}

const iconBtn = (bg, color) => ({
  background: bg, color, border: `1px solid ${color}33`, padding: "5px 10px",
  borderRadius: 6, fontSize: 11, fontWeight: 700, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 4
});

function EmptyState({ icon, title, sub }) {
  return (
    <div style={{ textAlign: "center", padding: "50px 20px", color: "#475569" }}>
      <div style={{ fontSize: 36, marginBottom: 10 }}>{icon}</div>
      <div style={{ fontSize: 15, fontWeight: 600, color: "#64748b" }}>{title}</div>
      <div style={{ fontSize: 12, marginTop: 4 }}>{sub}</div>
    </div>
  );
}

function GameCard({ game, onUpdate, onRemove, onLock }) {
  const u = (path, val) => onUpdate(game.id, path, val);
  return (
    <div style={{ background: "#1e293b", border: `1px solid ${game.locked ? "#1d4ed8" : "#334155"}`, borderRadius: 12, marginBottom: 14, overflow: "hidden" }}>
      {/* Header */}
      <div style={{ background: game.locked ? "#1e3a5f" : "#263548", padding: "12px 14px", display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <input type="date" value={game.date} onChange={(e) => u(["date"], e.target.value)} disabled={game.locked}
          style={{ background: "transparent", border: "1px solid #334155", color: "#94a3b8", padding: "3px 6px", borderRadius: 4, fontSize: 11 }} />
        <input placeholder="Away" value={game.awayTeam} onChange={(e) => u(["awayTeam"], e.target.value)} disabled={game.locked}
          style={{ ...teamInput, width: 110 }} />
        <span style={{ color: "#475569", fontWeight: 700, fontSize: 13 }}>@</span>
        <input placeholder="Home" value={game.homeTeam} onChange={(e) => u(["homeTeam"], e.target.value)} disabled={game.locked}
          style={{ ...teamInput, width: 110 }} />
        {game.locked && <span style={{ background: "#1d4ed8", color: "#bfdbfe", fontSize: 10, fontWeight: 700, padding: "2px 7px", borderRadius: 10, letterSpacing: 1, textTransform: "uppercase" }}>Done</span>}
        <div style={{ marginLeft: "auto", display: "flex", gap: 6 }}>
          <button onClick={() => onLock(game.id)} style={{ background: game.locked ? "#1e3a5f" : "#164e63", color: game.locked ? "#93c5fd" : "#67e8f9", border: `1px solid ${game.locked ? "#1d4ed8" : "#0e7490"}`, padding: "5px 10px", borderRadius: 6, cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
            {game.locked ? "✏️ Edit" : "🔒 Lock"}
          </button>
          {!game.locked && <button onClick={() => onRemove(game.id)} style={{ background: "#450a0a", color: "#fca5a5", border: "1px solid #7f1d1d", padding: "5px 8px", borderRadius: 6, cursor: "pointer", fontSize: 11 }}>✕</button>}
        </div>
      </div>

      {/* Lines */}
      <div style={{ padding: "0 12px 14px" }}>
        {["Total Hits", "Singles"].map((cat) => (
          <div key={cat} style={{ marginTop: 14 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: "#38bdf8", letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>{cat}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {["away", "home"].map((side) => (
                <LineRow key={side} label={(side === "away" ? game.awayTeam : game.homeTeam) || (side === "away" ? "Away" : "Home")}
                  lineObj={game.lines[cat][side]} locked={game.locked}
                  onChange={(field, val) => u(["lines", cat, side, field], val)} />
              ))}
            </div>
          </div>
        ))}
        <div style={{ marginTop: 14 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: "#a78bfa", letterSpacing: 2, textTransform: "uppercase", marginBottom: 8 }}>Game Total Doubles</div>
          <div style={{ maxWidth: "50%" }}>
            <LineRow label="Game Total" lineObj={game.lines["Game Total Doubles"].game} locked={game.locked}
              onChange={(field, val) => u(["lines", "Game Total Doubles", "game", field], val)} />
          </div>
        </div>
      </div>
    </div>
  );
}

const teamInput = { background: "#0f1923", border: "1px solid #334155", color: "#e2e8f0", padding: "5px 10px", borderRadius: 6, fontSize: 14, fontWeight: 700 };

function LineRow({ label, lineObj, locked, onChange }) {
  const implied = { over: oddsToImplied(lineObj.overOdds), under: oddsToImplied(lineObj.underOdds) };
  const resultColors = { Over: "#34d399", Under: "#f87171", Push: "#fcd34d", "": "#334155" };
  return (
    <div style={{ background: "#0f1923", border: "1px solid #334155", borderRadius: 8, padding: "10px 10px" }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: "#94a3b8", marginBottom: 8, textTransform: "uppercase" }}>{label}</div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 5, marginBottom: 6 }}>
        {[["Line", "line", "#e2e8f0"], ["Over", "overOdds", oddsColor(lineObj.overOdds)], ["Under", "underOdds", oddsColor(lineObj.underOdds)]].map(([lbl, field, col]) => (
          <div key={field}>
            <div style={{ fontSize: 9, color: "#475569", marginBottom: 3, textTransform: "uppercase" }}>{lbl}</div>
            <input placeholder={field === "line" ? "7.5" : "-110"} value={lineObj[field]} onChange={(e) => onChange(field, e.target.value)} disabled={locked}
              style={{ width: "100%", background: "#1e293b", border: `1px solid ${lineObj[field] && field !== "line" ? col : "#334155"}`, color: col, padding: "5px 6px", borderRadius: 5, fontSize: 12, fontWeight: 700, boxSizing: "border-box" }} />
            {field !== "line" && implied[field === "overOdds" ? "over" : "under"] !== null && (
              <div style={{ fontSize: 9, color: "#475569", marginTop: 2 }}>{formatPct(implied[field === "overOdds" ? "over" : "under"])}</div>
            )}
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 5, marginTop: 6 }}>
        {["Over", "Under", "Push"].map((r) => (
          <button key={r} onClick={() => !locked && onChange("result", lineObj.result === r ? "" : r)} disabled={locked && lineObj.result !== r}
            style={{ flex: 1, padding: "5px 2px", borderRadius: 6, border: `1px solid ${lineObj.result === r ? resultColors[r] : "#334155"}`, background: lineObj.result === r ? resultColors[r] + "22" : "transparent", color: lineObj.result === r ? resultColors[r] : "#475569", cursor: locked ? "default" : "pointer", fontSize: 11, fontWeight: 700 }}>
            {r}
          </button>
        ))}
      </div>
    </div>
  );
}

function TrendsTab({ trends, games }) {
  const locked = games.filter((g) => g.locked);
  const totalBets = trends.reduce((a, b) => a + b.total, 0);
  const totalHit = trends.reduce((a, b) => a + b.hit, 0);
  const hot = trends.filter((t) => t.total >= 3 && t.hit / t.total >= 0.6).sort((a, b) => b.hit / b.total - a.hit / a.total);
  const cold = trends.filter((t) => t.total >= 3 && t.hit / t.total <= 0.4).sort((a, b) => a.hit / a.total - b.hit / b.total);

  if (locked.length === 0) return <EmptyState icon="📊" title="No completed games yet" sub="Lock in results to see trend analysis" />;

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 10, marginBottom: 20 }}>
        {[["Games Tracked", locked.length, "#38bdf8"], ["Bets Logged", totalBets, "#a78bfa"], ["Overall Hit %", totalBets > 0 ? formatPct(totalHit / totalBets) : "-", "#34d399"], ["Hot Trends", hot.length, "#fcd34d"]].map(([label, val, color]) => (
          <div key={label} style={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 10, padding: "12px 14px" }}>
            <div style={{ fontSize: 22, fontWeight: 800, color }}>{val}</div>
            <div style={{ fontSize: 10, color: "#64748b", marginTop: 2, textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
        <TrendSection title="🔥 Going Over 60%+" trends={hot} color="#34d399" />
        <TrendSection title="❄️ Going Under 40%-" trends={cold} color="#f87171" />
      </div>

      <div style={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 10, overflow: "hidden" }}>
        <div style={{ padding: "12px 14px", borderBottom: "1px solid #334155", fontSize: 12, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: 1 }}>All Trends</div>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
            <thead>
              <tr style={{ background: "#0f1923" }}>
                {["Category", "Side", "Odds Bucket", "Hit/Total", "Rate", ""].map((h) => (
                  <th key={h} style={{ padding: "8px 10px", textAlign: "left", color: "#64748b", fontWeight: 600, fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {trends.map((t, i) => {
                const rate = t.total > 0 ? t.hit / t.total : 0;
                const barColor = rate >= 0.6 ? "#34d399" : rate <= 0.4 ? "#f87171" : "#fcd34d";
                return (
                  <tr key={i} style={{ borderTop: "1px solid #1e293b", background: i % 2 === 0 ? "#1e293b" : "#172035" }}>
                    <td style={{ padding: "8px 10px", color: "#e2e8f0", whiteSpace: "nowrap" }}>{t.label}</td>
                    <td style={{ padding: "8px 10px", color: t.side === "Over" ? "#34d399" : "#f87171", fontWeight: 700 }}>{t.side}</td>
                    <td style={{ padding: "8px 10px", color: "#94a3b8", whiteSpace: "nowrap" }}>{t.bucket}</td>
                    <td style={{ padding: "8px 10px", color: "#e2e8f0", fontWeight: 700 }}>{t.hit}/{t.total}</td>
                    <td style={{ padding: "8px 10px", color: barColor, fontWeight: 700 }}>{formatPct(rate)}</td>
                    <td style={{ padding: "8px 10px", minWidth: 80 }}>
                      <div style={{ background: "#334155", borderRadius: 4, height: 7 }}>
                        <div style={{ width: `${rate * 100}%`, height: "100%", background: barColor, borderRadius: 4 }} />
                      </div>
                    </td>
                  </tr>
                );
              })}
              {trends.length === 0 && <tr><td colSpan={6} style={{ padding: "20px", textAlign: "center", color: "#475569" }}>No trends yet</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function TrendSection({ title, trends, color }) {
  return (
    <div style={{ background: "#1e293b", border: "1px solid #334155", borderRadius: 10, overflow: "hidden" }}>
      <div style={{ padding: "10px 12px", borderBottom: "1px solid #334155", fontSize: 12, fontWeight: 700, color }}>{title}</div>
      <div style={{ padding: "8px" }}>
        {trends.length === 0 && <div style={{ color: "#475569", fontSize: 11, padding: "8px 4px" }}>Need 3+ samples</div>}
        {trends.slice(0, 5).map((t, i) => (
          <div key={i} style={{ padding: "7px 4px", borderBottom: "1px solid #0f1923", display: "flex", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: 11, color: "#e2e8f0", fontWeight: 600 }}>{t.label} {t.side}</div>
              <div style={{ fontSize: 10, color: "#475569" }}>{t.bucket}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontSize: 15, fontWeight: 800, color }}>{formatPct(t.hit / t.total)}</div>
              <div style={{ fontSize: 10, color: "#64748b" }}>{t.hit}/{t.total}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
